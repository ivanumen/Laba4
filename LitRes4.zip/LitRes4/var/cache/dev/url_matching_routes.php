<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/users' => [
            [['_route' => 'getUsers', '_controller' => 'App\\Controller\\UserController::getUsers'], null, ['GET' => 0], null, false, false, null],
            [['_route' => 'postUser', '_controller' => 'App\\Controller\\UserController::createUser'], null, ['POST' => 0], null, false, false, null],
        ],
        '/books' => [
            [['_route' => 'getBooks', '_controller' => 'App\\Controller\\BookController::getBooks'], null, ['GET' => 0], null, false, false, null],
            [['_route' => 'postBook', '_controller' => 'App\\Controller\\BookController::createBook'], null, ['POST' => 0], null, false, false, null],
        ],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_error/(\\d+)(?:\\.([^/]++))?(*:35)'
                .'|/user(?'
                    .'|(?:/([^/]++))?(?'
                        .'|(*:67)'
                    .')'
                    .'|\\-purchases/([^/]++)(*:95)'
                .')'
                .'|/purchase(?'
                    .'|(?:/([^/]++))?(*:129)'
                    .'|(*:137)'
                    .'|(?:/([^/]++))?(*:159)'
                .')'
                .'|/book(?:/([^/]++))?(?'
                    .'|(*:190)'
                .')'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        35 => [[['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null]],
        67 => [
            [['_route' => 'getUser', 'id' => 1, '_controller' => 'App\\Controller\\UserController::getUser1'], ['id'], ['GET' => 0], null, false, true, null],
            [['_route' => 'patchUser', 'id' => 1, '_controller' => 'App\\Controller\\UserController::patchUser'], ['id'], ['PATCH' => 0], null, false, true, null],
            [['_route' => 'deleteUser', 'id' => 1, '_controller' => 'App\\Controller\\UserController::deleteUser'], ['id'], ['DELETE' => 0], null, false, true, null],
        ],
        95 => [[['_route' => 'getPurchasesByUserId', '_controller' => 'App\\Controller\\PurchaseController::getPurchasesByUserId'], ['userId'], ['GET' => 0], null, false, true, null]],
        129 => [[['_route' => 'getPurchase', 'id' => 1, '_controller' => 'App\\Controller\\PurchaseController::getPurchase'], ['id'], ['GET' => 0], null, false, true, null]],
        137 => [[['_route' => 'postPurchase', '_controller' => 'App\\Controller\\PurchaseController::createPurchase'], [], ['POST' => 0], null, false, false, null]],
        159 => [[['_route' => 'deletePurchase', 'id' => 1, '_controller' => 'App\\Controller\\PurchaseController::deletePurchase'], ['id'], ['DELETE' => 0], null, false, true, null]],
        190 => [
            [['_route' => 'getBook', 'id' => 1, '_controller' => 'App\\Controller\\BookController::getBook'], ['id'], ['GET' => 0], null, false, true, null],
            [['_route' => 'patchBook', 'id' => 1, '_controller' => 'App\\Controller\\BookController::patchBook'], ['id'], ['PATCH' => 0], null, false, true, null],
            [['_route' => 'deleteBook', 'id' => 1, '_controller' => 'App\\Controller\\BookController::deleteBook'], ['id'], ['DELETE' => 0], null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
